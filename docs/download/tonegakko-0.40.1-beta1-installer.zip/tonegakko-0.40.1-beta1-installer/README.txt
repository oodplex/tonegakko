Tonegakko 0.40 beta 1.0.1 for the M-VAVE FM-1: the first open beta, fixed for the newer FM-1s
(experimental firmware; installing it is at your own risk; the installer can put M-VAVE's own firmware back)

An island, printed like a woodblock, where small creatures called the Sonari wander and sing together. What they
play together becomes new styles, found one by one into the Book, from THE FIRST EVENING to DAYBREAK. Fourteen
Sonari to meet, 32 styles to find, and a real instrument the whole time: the keys play the chosen Sonari, and MIDI
goes in and out. Not affiliated with M-VAVE. Built on fm1-base and felucca-bsp (MPL-2.0).


INSTALL (about five minutes), on a computer with Chrome or Edge, the FM-1 plugged in by USB
---------------------------------------------------------------------------------------------
  1. In a terminal, inside this folder, start a small web server:
         python3 -m http.server 8000
  2. In Chrome or Edge, open   http://localhost:8000/install/   and follow the page.
  3. The FM-1 restarts into Tonegakko: the logo prints itself, and the boot screen shows 0.40.1-BETA1.

  Opening index.html straight from the disk does not work: the page has to fetch the firmware file.
  If your FM-1 runs M-VAVE's "FM1 Open" firmware, put M-VAVE's standard FM-1 firmware back first.
  Going back: the same installer page can put M-VAVE's own firmware back at any time.
  From the command line instead (pip3 install mido python-rtmidi):
         python3 base/tools/fm1_install.py tonegakko-0.40.1-beta1.fwsc


WHAT 1.0.1 CHANGES
------------------
  FM-1s sold since autumn 2026 (many from AliExpress, the logo printed on the front) have a different memory
  chip, a UC25HQ80. Beta 1 did not know it: on those FM-1s it played, but kept nothing after switching off, and
  the installer page could not update it or put M-VAVE's firmware back. 1.0.1 is built on the newer fm1-base,
  which knows both chips. The game itself is the same as beta 1.

  Installed beta 1 on one of the newer FM-1s? The page cannot reach it, so put M-VAVE's firmware back first:
   1. Hold REC while you switch the FM-1 on: it starts in the chip's own update mode.
   2. On a Mac or Linux computer, plug it in and run this in a terminal (felucca-bsp's rescue: it backs the FM-1
      up, then writes M-VAVE's own firmware):
         bash -c "$(curl -fsSL https://raw.githubusercontent.com/hugelton/felucca-bsp/main/tools/fm1_rescue.sh)"
   3. Then install 1.0.1 from the page as above.
  On Windows, or if it does not work, open an issue (below) and we will help.


YOUR FIRST TEN MINUTES
----------------------
  Every button opens its own page, and the same button again comes back. Lost? Press HOME: a card names every
  knob, button and key on the page you are on. The island also teaches itself, one tip at a time.

  MEET
   1. Switch on. The logo prints itself, then the island opens, already playing.
   2. Turn SELECT to choose who. A ring turns at its feet, a pin bobs over its head, its name shows for a moment.
      SEL brings the chosen one in, or lets it rest.
      Or hold EDIT: every Sonari shows the button it sits on (FX, SEL, ENV, LFO, HOME, SAVE, ARP, SEQ). Press one
      to choose that Sonari straight away.
   3. Play the keys. They always play the chosen one, soft or hard. Press EDIT to look closer: its SOUND page.

  SHAPE
   4. On the SOUND page, turn SELECT: the chosen one becomes another Sonari. There are fourteen.
   5. Hold EDIT and let go: its SYNTH, the sound taken apart as five little scenes that move with the knobs (an orrery,
      clockwork, a water mill, a loom, an aquarium). SELECT picks the scene; K1 to K4 are drawn in their own
      colours: K1 blue, K2 red, K3 yellow, K4 green.
   6. Hold FX and press white keys: a punch-in for each key, as long as you hold it.

  EXPLORE
   7. On the island, K2 brings the weather (haze, fog, then rain) and K4 the wind (and the tempo).
   8. Press GLO and turn K1: the key, and with it the hour. The sun goes down into the night.
   9. Leave it playing: the seasons turn every few minutes. What the Sonari play together becomes styles,
      written into the Book (GLO, then THE BOOK).


THE CONTROLS AT A GLANCE
------------------------
  SELECT          who is chosen (on the island); on other pages, that page's own
  PRESETS / ALG.  the chosen one's pitch / its phrase
  K1 K2 K3 K4     wander, space (and the weather), tone, tempo (and the wind)
  SEL             the chosen one joins or rests
  EDIT            tap: its SOUND page; hold and let go: its SYNTH page;
                  hold, then a Sonari's button: choose that Sonari
  GLO             the island from the sea: key (the hour), tuning, swing, tempo, the Book, the settings
  FX              tap: the effects; hold and press white keys: punch-ins
  ENV LFO ARP     its note shape, its wobble, its pattern
  SEQ             its steps (hold: cleared)
  SAVE            scenes (hold and press a white key: keep or call one)
  HOME            help, anywhere
  PLAY / REC      play or stop (held: LISTEN) / record a take into the chosen one (held: take it back)
  OCT- OCT+       the chosen one's octave; both together: LIVE (the keys conduct everyone)
  Keys            play the chosen one; MIDI in plays it too


GOOD TO KNOW
------------
  - Settings: GLO, then SETTINGS (tips, the season, Bluetooth MIDI, MIDI out, a new island).
  - Bluetooth MIDI is off until you turn it on in the settings.
  - A filter on many Sonari at once costs the sound engine more. Hold OCT- and OCT+ and press GLO for a strip that
    shows the load.
  - The SYNTH scenes' pictures are still being polished, the orrery most of all. Their sound is final.
  - Played an earlier Tonegakko (0.18 or later)? Your island, the Book and your scenes carry over.
  - Following on a computer: follow/ in this folder draws the game in Chrome from what the FM-1 sends
    (served as above: http://localhost:8000/follow/).


FEEDBACK
--------
  Please open an issue at https://github.com/oodplex/tonegakko/issues : what you did, what you expected, what
  happened instead, and the version the boot screen shows (0.40.1-BETA1).


Files: tonegakko-0.40.1-beta1.fwsc (the firmware), install/ (the installer), follow/ (the follow page), firmware/ (the
firmware again, m-bootloader 1.2 with its licences), words/ (what a screen reader says), index.html (the front page).
Built on fm1-base, https://github.com/charlesvestal/fm1-base (MPL-2.0); m-bootloader under the MIT licence (firmware/).
